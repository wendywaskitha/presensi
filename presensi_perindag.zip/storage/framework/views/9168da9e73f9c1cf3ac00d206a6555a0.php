<?php
    $uniqueActionId = $getUniqueActionId();

    $statePath = $getStatePath();

    $shouldRefresh = $shouldRefresh();

    $data = $this->mountedTableBulkAction ? $this->getMountedTableBulkActionForm()->getState() : $this->getMountedTableActionForm()->getState();

    $shouldPrint = is_array($data) && array_key_exists('table_view', $data) && $data['table_view'] == 'print-' . $uniqueActionId;

    $printContent = $shouldPrint ? $getPrintHTML() : '';
?>

<input id="<?php echo e($statePath); ?>" type="hidden" <?php echo e($applyStateBindingModifiers('wire:model')); ?>="<?php echo e($statePath); ?>">

<?php if (isset($component)) { $__componentOriginal0942a211c37469064369f887ae8d1cef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0942a211c37469064369f887ae8d1cef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.modal.index','data' => ['id' => 'preview-modal','width' => '7xl','displayClasses' => 'block','darkMode' => config('filament.dark_mode'),'xData' => '{
        shouldRefresh: '.e($shouldRefresh ? 'true' : 'false').',
        shouldPrint: '.e($shouldPrint ? 'true' : 'false').'

    }
    ','xInit' => '$wire.$on(\'open-preview-modal-'.e($uniqueActionId).'\', function() {
        triggerInputEvent(\''.e($statePath).'\', \''.e(uniqid()).'\');
        isOpen = true;
    });
    
    $wire.$on(\'close-preview-modal-'.e($uniqueActionId).'\', () => { isOpen = false; });
    
    if (shouldRefresh) {
        $wire.dispatch(\'close-preview-modal-'.e($uniqueActionId).'\');
     
        triggerInputEvent(\''.e($statePath).'\', \''.e(uniqid()).'\');
        
        $wire.dispatch(\'open-preview-modal-'.e($uniqueActionId).'\');
    }

    
    if (shouldPrint) {
        window.printHTML(`'.$printContent.'`, \''.e($statePath).'\', \''.e($uniqueActionId).'\');
    }
    ','heading' => $getPreviewModalHeading()]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'preview-modal','width' => '7xl','display-classes' => 'block','dark-mode' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(config('filament.dark_mode')),'x-data' => '{
        shouldRefresh: '.e($shouldRefresh ? 'true' : 'false').',
        shouldPrint: '.e($shouldPrint ? 'true' : 'false').'

    }
    ','x-init' => '$wire.$on(\'open-preview-modal-'.e($uniqueActionId).'\', function() {
        triggerInputEvent(\''.e($statePath).'\', \''.e(uniqid()).'\');
        isOpen = true;
    });
    
    $wire.$on(\'close-preview-modal-'.e($uniqueActionId).'\', () => { isOpen = false; });
    
    if (shouldRefresh) {
        $wire.dispatch(\'close-preview-modal-'.e($uniqueActionId).'\');
     
        triggerInputEvent(\''.e($statePath).'\', \''.e(uniqid()).'\');
        
        $wire.dispatch(\'open-preview-modal-'.e($uniqueActionId).'\');
    }

    
    if (shouldPrint) {
        window.printHTML(`'.$printContent.'`, \''.e($statePath).'\', \''.e($uniqueActionId).'\');
    }
    ','heading' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getPreviewModalHeading())]); ?>
    <div class="preview-table-wrapper space-y-4">
        <table class="preview-table dark:bg-gray-800 dark:text-white dark:border-gray-700" x-init="$wire.$on('print-table-<?php echo e($uniqueActionId); ?>', function() {
            triggerInputEvent('<?php echo e($statePath); ?>', 'print-<?php echo e($uniqueActionId); ?>')
        })">
            <tr class="dark:border-gray-700">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $getAllColumns(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th class="dark:border-gray-700">
                        <?php echo e($column->getLabel()); ?>

                    </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tr>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $getRows(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="dark:border-gray-700">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $getAllColumns(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="dark:border-gray-700">
                            <?php echo e($row[$column->getName()]); ?>

                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </table>
        <div>
            <?php if (isset($component)) { $__componentOriginal0c287a00f29f01c8f977078ff96faed4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0c287a00f29f01c8f977078ff96faed4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.pagination.index','data' => ['paginator' => $getRows(),'pageOptions' => $this->getTable()->getPaginationPageOptions(),'class' => 'preview-table-pagination px-3 py-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::pagination'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['paginator' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getRows()),'page-options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($this->getTable()->getPaginationPageOptions()),'class' => 'preview-table-pagination px-3 py-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0c287a00f29f01c8f977078ff96faed4)): ?>
<?php $attributes = $__attributesOriginal0c287a00f29f01c8f977078ff96faed4; ?>
<?php unset($__attributesOriginal0c287a00f29f01c8f977078ff96faed4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0c287a00f29f01c8f977078ff96faed4)): ?>
<?php $component = $__componentOriginal0c287a00f29f01c8f977078ff96faed4; ?>
<?php unset($__componentOriginal0c287a00f29f01c8f977078ff96faed4); ?>
<?php endif; ?>
        </div>
    </div>
     <?php $__env->slot('footer', null, []); ?> 
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $getFooterActions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($action); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0942a211c37469064369f887ae8d1cef)): ?>
<?php $attributes = $__attributesOriginal0942a211c37469064369f887ae8d1cef; ?>
<?php unset($__attributesOriginal0942a211c37469064369f887ae8d1cef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0942a211c37469064369f887ae8d1cef)): ?>
<?php $component = $__componentOriginal0942a211c37469064369f887ae8d1cef; ?>
<?php unset($__componentOriginal0942a211c37469064369f887ae8d1cef); ?>
<?php endif; ?>
<?php /**PATH D:\JAKUTECH\presensi_perindag\vendor\alperenersoy\filament-export\src/../resources/views/components/table_view.blade.php ENDPATH**/ ?>