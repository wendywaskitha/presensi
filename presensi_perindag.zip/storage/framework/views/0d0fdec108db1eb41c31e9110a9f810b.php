<table <?php echo e($attributes->merge(['class' => 'w-full'])); ?>>
    <?php echo e($slot); ?>

</table>
<?php /**PATH D:\JAKUTECH\presensi_perindag\vendor\laravel\pulse\src/../resources/views/components/table.blade.php ENDPATH**/ ?>