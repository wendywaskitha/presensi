<thead class="sticky z-10 top-0 bg-white dark:bg-gray-900">
    <?php echo e($slot); ?>

</thead>
<?php /**PATH D:\JAKUTECH\presensi_perindag\vendor\laravel\pulse\src/../resources/views/components/thead.blade.php ENDPATH**/ ?>