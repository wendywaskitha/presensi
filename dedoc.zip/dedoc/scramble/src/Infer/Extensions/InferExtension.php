<?php

namespace Dedoc\Scramble\Infer\Extensions;

interface InferExtension {}
