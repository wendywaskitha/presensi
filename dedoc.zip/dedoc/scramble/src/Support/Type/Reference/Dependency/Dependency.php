<?php

namespace Dedoc\Scramble\Support\Type\Reference\Dependency;

interface Dependency {}
